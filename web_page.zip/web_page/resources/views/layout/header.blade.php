@extends('layout.main')

@section('title','header part')

@section('header')
<nav class="navbar navbar-default navbar-fixed-top">
		<div class="container">
			<div class="row">
				<div class="col-md-2">
					<div class="site-logo">
						<a href="index.html" class="brand">PrimeItZen</a>
					</div>
				</div>					  

				<div class="col-md-10">	 
					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#menu">
							<i class="fa fa-bars"></i>
						</button>
					</div>
					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse" id="menu">
						<ul class="nav navbar-nav navbar-right">
							  <li><a href="{{ url('/index')}}">Home</a></li>
							  <li><a href="{{ url('/about')}}">About Us</a></li>
							  <li><a href="{{ url('/portfolio')}} ">Portfolio</a></li>
							 			                                                                  								  
							  <li><a href="{{ url('/contact')}} ">Contact</a></li>
						</ul>
					</div>
					<!-- /.Navbar-collapse -->		 
				</div>
			</div>
		</div>		
	</nav>

@endsection
