@extends('layout.main')





@section('header')
@include('layout.header')
@endsection

@section('home')
@include('layout.home')
@endsection

@section('about')
@include('layout.about')
@endsection

@section('portfolio')
@include('layout.portfolio')
@endsection

@section('contact')
@include('layout.contact')
@endsection

@section('footer')
@include('layout.footer')
@endsection