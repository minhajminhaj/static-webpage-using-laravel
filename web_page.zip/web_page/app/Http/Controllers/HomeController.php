<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    //
		public function header()
		{
			return view('layout.header');
		}
		public function footer()
		{

			return view('layout.footer');
		}
		
	    public function index()
	    {
	    		return view('index');
	    }
	    
	    public function about()
	    {
	    	return view ('layout.about');
	    }

    	public function contact()
    	{
    		return view('layout.contact');
    	}

    	public function portfolio()
    	{
    	 return view('layout.portfolio');
    	}
    	public function home()
    	{
    	 return view('layout.home');
    	}

}
